package pe.edu.cafeteria;

public class Aplication {
    public static void main(String[] args) {
        System.out.println("holas");
        ProductosApplication.main(args);
    }
}
